# DuaLang 15 Pro — guide très simple depuis un Samsung, sans PC

Vous disposez déjà d'un dépôt GitHub pour la 14.4. Réutilisez-le.

## Déposer les deux fichiers dans le dépôt

1. Téléchargez les fichiers **`DuaLang_15_PROJET_COMPLET.zip`** et **`COLLER_DANS_GITHUB_DUALANG_15.yml`** depuis cette conversation.
2. Sur votre Samsung, dans Chrome, ouvrez votre dépôt GitHub, puis dans le menu de Chrome (⋮ en haut à droite) activez « Site pour ordinateur » si « Add file » est absent.
3. Dans GitHub choisissez **Add file → Upload files**. Sélectionnez **DuaLang_15_PROJET_COMPLET.zip** **sans le décompresser** ; validez **Commit changes**.
4. Dans le même dépôt, choisissez **Add file → Create new file**. Saisissez comme **nom complet** : `.github/workflows/compiler-dualang-15.yml`.
5. Ouvrez le fichier `COLLER_DANS_GITHUB_DUALANG_15.yml` téléchargé, copiez **tout son texte**, collez-le dans l'éditeur GitHub, puis validez **Commit changes**.

## Lancer la compilation

6. Dans le dépôt, ouvrez l'onglet **Actions**. Si GitHub demande d'activer Actions, autorisez les actions du dépôt.
7. Dans la liste choisissez **DuaLang 15 - Compiler ZIP en APK**.
8. Touchez **Run workflow**, sélectionnez **main**, puis touchez à nouveau **Run workflow**. Si le workflow a déjà démarré au moment du commit, ouvrez directement son exécution.
9. Attendez le résultat affiché par GitHub. Une **coche verte** signifie que le build est réussi. En cas de **croix rouge**, ouvrez l'étape en échec et envoyez-nous une capture pour corriger exactement l'erreur.
10. Dans l'exécution réussie, descendez à **Artifacts** et téléchargez **DuaLang-15-APK**.
11. Le fichier téléchargé est une archive d'artifact GitHub : décompressez-la, touchez **app-debug.apk** puis autorisez l'installation d'applications depuis Chrome/Mes fichiers si Android le demande.

## Remarques

- N'essayez pas d'ouvrir le ZIP source en tant qu'application ; seul `app-debug.apk` est installable.
- Si Android refuse une mise à jour à cause de signatures différentes, ne supprimez pas l'ancienne application sans réfléchir : sa désinstallation efface l'historique local.
- Le ZIP source n'est pas une APK : GitHub doit réussir la compilation pour produire l'APK.
