# DuaLang 15 Pro — application Android

**Version 15.0 (versionCode 150)**, sur la base de DuaLang 14.4. Projet Android Java complet.

## Interface professionnelle

- Couverture bleu marine, titre DuaLang 15, signature **Développé par Moussa Khalid**.
- Barre de quatre outils : **Écrire • Photo • Image • Écouter**, microphone central et panneaux source/traduction séparés.
- 5 langues de traduction : français, anglais, indonésien, vietnamien et filipino/tagalog.
- 8 sens de traduction via le français, avec bouton d'inversion.
- Sélection parmi 5 langues pour les commandes principales de l'interface : français, anglais, indonésien, vietnamien, filipino.
- Réglages en **page complète bleu marine**, avec choix langue et mode hors ligne seulement.
- Traduction locale ML Kit, téléchargement de 5 modèles, mode automatique ou modèles déjà installés seulement.
- Photo via caméra et images via galerie pour OCR du texte latin (puis traduction).
- Dictée Android, lecture vocale, partage Android (WhatsApp si installé), historique (50), favoris, copie, effacement.
- Pas de publicité et pas de compte.
- Compatibilité avec le stockage de DuaLang 14.4 : identifiant de paquet `com.dualang.pro` et `SharedPreferences` `dualang_14_4` conservés.

**Limites réelles :** la première installation des modèles exige Internet. Le service vocal du téléphone peut nécessiter Internet. La lecture vocale dépend des voix Android installées. Le partage WhatsApp ouvre la feuille de partage ; il n'envoie pas de message sans intervention de l'utilisateur. Le mode OCR est pour caractères latins.

## Compilation Android et GitHub

- AGP 8.6.1, Gradle 8.7, Java 17, SDK Android 35, minSDK 26.
- Dépendances `com.google.mlkit:translate:17.0.3`, `com.google.mlkit:text-recognition:16.0.1`, `androidx.core:core:1.13.1`.
- Si les **fichiers sont extraits à la racine** du dépôt : workflow embarqué `.github/workflows/android-apk.yml` pour fabriquer un APK debug installable.
- Si seul le **ZIP complet est importé**, utiliser le workflow externe `COLLER_DANS_GITHUB_DUALANG_15.yml` et le créer dans `.github/workflows/compiler-dualang-15.yml`.
- L'artefact généré dans **Actions** se nomme **DuaLang-15-APK** ; télécharger puis décompresser afin d'obtenir `app-debug.apk`.
- L'APK Debug est signé par une clé de développement propre à l'exécution GitHub. Une installation par-dessus une version signée différemment peut être refusée par Android. Sauvegarder l'historique important avant toute désinstallation.
- Publication Play Store : réaliser une version release signée avec une clé privée à soi, hors dépôt public.

**Contrôles réalisés dans ce paquet :** structure de projet, XML, huit directions et présence des classes/fonctions, version 15, vérification des noms de dépendances et des workflows. Le SDK Android et Gradle ne sont pas disponibles localement : **aucune compilation APK ni test sur téléphone n'a pu être effectué ici**. La compilation réelle s'exécutera dans GitHub Actions.

Voir `GUIDE_SAMSUNG_VERSION_15.md`.
