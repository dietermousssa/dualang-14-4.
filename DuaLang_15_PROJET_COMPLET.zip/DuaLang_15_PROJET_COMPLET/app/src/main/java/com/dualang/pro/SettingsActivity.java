package com.dualang.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateRemoteModel;

import java.util.concurrent.atomic.AtomicInteger;

/** Full dark-navy settings screen, introduced in DuaLang 15. */
public final class SettingsActivity extends Activity {
    private static final int NAVY = Color.rgb(8,25,52);
    private static final int CARD = Color.rgb(20,45,82);
    private static final int BLUE = Color.rgb(42,125,255);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(184,205,238);
    private static final String[] LANG_CODES = {"fr", "en", "id", "vi", "tl"};
    private static final String[] LANG_OPTIONS = {"🇫🇷 Français", "🇬🇧 English", "🇮🇩 Bahasa Indonesia", "🇻🇳 Tiếng Việt", "🇵🇭 Filipino"};
    private TextView progress;
    private SharedPreferences prefs;
    private boolean destroyed;
    private String t(String french) { return UiText.get(this, french); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("dualang_14_4", MODE_PRIVATE);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(NAVY);
        scroll.setFillViewport(true);
        LinearLayout screen = vertical();
        screen.setPadding(dp(19), dp(23), dp(19), dp(34));
        scroll.addView(screen);
        setContentView(scroll);

        Button back = button("← " + t("Retour"));
        back.setBackground(pill(Color.rgb(30,60,106), 16));
        screen.addView(back, new LinearLayout.LayoutParams(dp(108), dp(42)));
        back.setOnClickListener(v -> finish());
        TextView heading = label("⚙ " + t("Réglages"), 30, WHITE, true);
        heading.setPadding(0, dp(27), 0, dp(4));
        screen.addView(heading);
        TextView sub = label("DuaLang 15 Pro  •  Developed by Moussa Khalid", 13, MUTED, false);
        sub.setPadding(0, 0, 0, dp(23));
        screen.addView(sub);

        LinearLayout languageCard = card();
        languageCard.addView(label("🌐 " + t("Langue de l’interface"), 18, WHITE, true));
        TextView current = label(LANG_OPTIONS[langIndex()], 15, MUTED, false);
        current.setPadding(0, dp(9), 0, dp(5));
        languageCard.addView(current);
        languageCard.setOnClickListener(v -> chooseLanguage());
        screen.addView(languageCard, itemParams());

        LinearLayout offlineCard = card();
        offlineCard.addView(label("📴 " + t("Mode hors ligne uniquement"), 17, WHITE, true));
        TextView offHint = label(t("Utiliser uniquement les modèles de traduction déjà téléchargés."), 13, MUTED, false);
        offHint.setPadding(0, dp(8), 0, dp(12));
        offlineCard.addView(offHint);
        Switch toggle = new Switch(this);
        toggle.setText(prefs.getBoolean("offline_only", false) ? "OFFLINE" : "AUTO");
        toggle.setTextColor(WHITE);
        toggle.setThumbTintList(ColorStateList.valueOf(BLUE));
        toggle.setChecked(prefs.getBoolean("offline_only", false));
        toggle.setOnCheckedChangeListener((buttonView, checked) -> {
            prefs.edit().putBoolean("offline_only", checked).apply();
            toggle.setText(checked ? "OFFLINE" : "AUTO");
        });
        offlineCard.addView(toggle);
        screen.addView(offlineCard, itemParams());

        LinearLayout models = card();
        models.addView(label("⬇ " + t("Télécharger les modèles"), 17, WHITE, true));
        TextView modelHint = label(t("Télécharger les 5 langues pour traduire hors ligne."), 13, MUTED, false);
        modelHint.setPadding(0, dp(7), 0, dp(13));
        models.addView(modelHint);
        Button download = button("↓  " + t("Télécharger les modèles"));
        download.setBackground(pill(BLUE, 12));
        models.addView(download, new LinearLayout.LayoutParams(-1, dp(48)));
        progress = label("", 13, MUTED, false);
        progress.setPadding(0, dp(12), 0, 0);
        models.addView(progress);
        download.setOnClickListener(v -> downloadModels(download));
        screen.addView(models, itemParams());

        LinearLayout data = card();
        data.addView(label("♻ " + t("Effacer l’historique"), 17, WHITE, true));
        TextView desc = label(t("Supprimer les traductions et favoris enregistrés."), 13, MUTED, false);
        desc.setPadding(0, dp(8), 0, 0);
        data.addView(desc);
        data.setOnClickListener(v -> clearHistory());
        screen.addView(data, itemParams());

        LinearLayout about = card();
        about.addView(label("ⓘ " + t("À propos et confidentialité"), 17, WHITE, true));
        TextView aboutHint = label("DuaLang 15 Pro • 5 languages • 8 directions", 13, MUTED, false);
        aboutHint.setPadding(0, dp(8), 0, 0);
        about.addView(aboutHint);
        about.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("DuaLang 15 Pro")
                .setMessage("Développé par Moussa Khalid.\n\nTraduction écrite sur l’appareil avec modèles ML Kit téléchargeables. "
                        + "OCR local du texte en alphabet latin, caméra et galerie. "
                        + "Historique et favoris stockés localement. La dictée dépend du service vocal Android, "
                        + "qui peut utiliser Internet. Partage uniquement après action de l’utilisateur. "
                        + "Aucune publicité ni compte DuaLang requis.")
                .setPositiveButton("OK", null).show());
        screen.addView(about, itemParams());
    }

    private int langIndex() {
        String code = prefs.getString("ui_language", "fr");
        for (int i=0; i<LANG_CODES.length; i++) if (LANG_CODES[i].equals(code)) return i;
        return 0;
    }

    private void chooseLanguage() {
        new AlertDialog.Builder(this)
                .setTitle(t("Langue de l’interface"))
                .setSingleChoiceItems(LANG_OPTIONS, langIndex(), (dialog, which) -> {
                    prefs.edit().putString("ui_language", LANG_CODES[which]).apply();
                    dialog.dismiss();
                    render();
                }).setNegativeButton(t("Annuler"), null).show();
    }

    private void downloadModels(Button download) {
        download.setEnabled(false);
        progress.setText("0/5");
        RemoteModelManager manager = RemoteModelManager.getInstance();
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        AtomicInteger completed = new AtomicInteger();
        AtomicInteger failures = new AtomicInteger();
        for (String code : LANG_CODES) {
            TranslateRemoteModel model = new TranslateRemoteModel.Builder(code).build();
            manager.download(model, conditions).addOnFailureListener(err -> failures.incrementAndGet())
                .addOnCompleteListener(task -> {
                    int n = completed.incrementAndGet();
                    if (destroyed) return;
                    progress.setText(n + "/5  •  " + (n - failures.get()) + " succès");
                    if (n == LANG_CODES.length) {
                        download.setEnabled(true);
                        progress.setText(failures.get() == 0 ? "✓ 5/5 modèles disponibles hors ligne"
                            : "Échec pour " + failures.get() + " modèle(s) : vérifier la connexion.");
                    }
                });
        }
    }

    private void clearHistory() {
        new AlertDialog.Builder(this).setTitle(t("Effacer l’historique"))
            .setMessage("Effacer toutes les traductions et tous les favoris ?")
            .setPositiveButton(t("Effacer"), (dialog, which) -> prefs.edit().remove("history").apply())
            .setNegativeButton(t("Annuler"), null).show();
    }

    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }
    private LinearLayout card() {
        LinearLayout c = vertical();
        c.setPadding(dp(17), dp(18), dp(17), dp(18));
        c.setBackground(pill(CARD, 19));
        return c;
    }
    private LinearLayout.LayoutParams itemParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        return p;
    }
    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        return b;
    }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(color);
        v.setTextSize(size);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private GradientDrawable pill(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }
    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
    @Override protected void onDestroy() { destroyed = true; super.onDestroy(); }
}
