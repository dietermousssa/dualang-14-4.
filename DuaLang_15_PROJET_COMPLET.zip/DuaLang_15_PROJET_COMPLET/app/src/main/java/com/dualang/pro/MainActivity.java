package com.dualang.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** DuaLang 15 Pro: five languages, eight directions, offline translation, camera OCR, speech and history. */
public final class MainActivity extends Activity {
    private static final int REQUEST_CAMERA = 100;
    private static final int REQUEST_IMAGE = 101;
    private static final int REQUEST_SPEECH = 102;
    // Keep v14.4 SharedPreferences name to preserve user history, favorites and direction on upgrade.
    private static final String PREFS = "dualang_14_4";
    private static final String KEY_HISTORY = "history";

    private static final int NAVY = Color.rgb(8, 25, 52);
    private static final int BLUE = Color.rgb(34, 109, 247);
    private static final int BLUE_LIGHT = Color.rgb(231, 241, 255);
    private static final int TEXT = Color.rgb(24, 48, 80);
    private static final int MUTED = Color.rgb(104, 122, 145);
    private static final int BACKGROUND = Color.rgb(244, 248, 255);
    private static final int WHITE = Color.WHITE;

    private static final String[] LANG_NAMES = {
            "Français", "Anglais", "Indonésien", "Vietnamien", "Filipino"
    };
    private static final String[] LANG_FLAGS = {"🇫🇷", "🇬🇧", "🇮🇩", "🇻🇳", "🇵🇭"};
    private static final String[] LANG_PLACES = {
            "Tour Eiffel", "Big Ben", "Borobudur", "Hạ Long", "Manille"
    };
    private static final String[] LANG_CODES = {"fr", "en", "id", "vi", "tl"};
    private static final String[] SPEECH_CODES = {"fr-FR", "en-US", "id-ID", "vi-VN", "fil-PH"};
    // Exactly eight validated directions: French <-> each of the four other languages.
    private static final int[][] DIRECTIONS = {
            {0, 1}, {1, 0}, {0, 2}, {2, 0},
            {0, 3}, {3, 0}, {0, 4}, {4, 0}
    };

    private EditText sourceInput;
    private TextView directionLabel;
    private TextView resultValue;
    private TextView statusValue;
    private Button translateButton;
    private TextToSpeech textToSpeech;
    private Uri pendingCameraUri;
    private int direction = 2;
    private int translationRequest = 0;
    private boolean destroyed = false;
    private boolean hasTranslatedResult = false;
    private String lastLanguage = "fr";

    private String t(String french) {
        return UiText.get(this, french);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        direction = getPreferences(MODE_PRIVATE).getInt("direction", 2);
        if (direction < 0 || direction >= DIRECTIONS.length) direction = 2;
        if (savedInstanceState != null) {
            String uri = savedInstanceState.getString("photoUri");
            if (uri != null) pendingCameraUri = Uri.parse(uri);
        }
        lastLanguage = getSharedPreferences(PREFS, MODE_PRIVATE).getString("ui_language", "fr");
        createInterface();
        if (savedInstanceState != null) {
            sourceInput.setText(savedInstanceState.getString("sourceText", ""));
            hasTranslatedResult = savedInstanceState.getBoolean("hasTranslation", false);
            if (hasTranslatedResult) resultValue.setText(savedInstanceState.getString("resultText", ""));
        }
        textToSpeech = new TextToSpeech(this, state -> {
            if (state != TextToSpeech.SUCCESS) {
                setStatus("Synthèse vocale indisponible sur ce téléphone.");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        String nextLanguage = getSharedPreferences(PREFS, MODE_PRIVATE).getString("ui_language", "fr");
        if (!nextLanguage.equals(lastLanguage) && sourceInput != null) {
            String savedSource = sourceInput.getText().toString();
            String savedResult = resultValue == null ? "" : resultValue.getText().toString();
            lastLanguage = nextLanguage;
            createInterface();
            sourceInput.setText(savedSource);
            if (hasTranslatedResult && savedResult != null && !savedResult.trim().isEmpty()) resultValue.setText(savedResult);
        }
        if (statusValue != null) {
            boolean onlyOffline = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("offline_only", false);
            setStatus(onlyOffline ? t("Mode hors ligne actif : seuls les modèles déjà installés seront utilisés.") : t("Mode automatique : téléchargement initial possible via Internet."));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (pendingCameraUri != null) out.putString("photoUri", pendingCameraUri.toString());
        if (sourceInput != null) out.putString("sourceText", sourceInput.getText().toString());
        if (resultValue != null) out.putString("resultText", resultValue.getText().toString());
        out.putBoolean("hasTranslation", hasTranslatedResult);
    }

    private void createInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout screen = vertical();
        screen.setPadding(dp(15), dp(14), dp(15), dp(28));
        scroll.addView(screen);
        setContentView(scroll);

        LinearLayout header = vertical();
        header.setPadding(dp(19), dp(19), dp(19), dp(19));
        header.setBackground(gradient(NAVY, Color.rgb(25, 65, 119), 24));
        screen.addView(header, blockLayout(0));

        LinearLayout brand = horizontal();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = makeText("D", 25, WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(rounded(BLUE, 15));
        brand.addView(mark, new LinearLayout.LayoutParams(dp(49), dp(49)));
        LinearLayout nameStack = vertical();
        nameStack.setPadding(dp(12), 0, 0, 0);
        nameStack.addView(makeText("DuaLang 15", 24, WHITE, true));
        nameStack.addView(makeText(t("INTERFACE PRO  •  TRADUCTION INTELLIGENTE"), 10,
                Color.rgb(199, 221, 252), true));
        brand.addView(nameStack, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(brand);
        TextView intro = makeText(t("Parlez, écrivez ou photographiez. Traduisez dans 5 langues, même hors ligne après téléchargement des modèles."),
                13, Color.rgb(218, 231, 250), false);
        intro.setPadding(0, dp(14), 0, 0);
        header.addView(intro);
        TextView creator = makeText(t("Développé par Moussa Khalid  •  DuaLang 15 Pro"), 11, Color.rgb(176, 213, 253), false);
        creator.setPadding(0, dp(10), 0, 0);
        header.addView(creator);

        TextView section = makeText(t("DIRECTION DE TRADUCTION"), 11, MUTED, true);
        section.setPadding(dp(3), dp(22), 0, dp(8));
        screen.addView(section);

        LinearLayout directionCard = horizontal();
        directionCard.setGravity(Gravity.CENTER_VERTICAL);
        directionCard.setPadding(dp(16), dp(15), dp(9), dp(15));
        directionCard.setBackground(rounded(WHITE, 18));
        directionLabel = makeText("", 15, NAVY, true);
        directionLabel.setGravity(Gravity.CENTER_VERTICAL);
        directionCard.addView(directionLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        directionLabel.setOnClickListener(v -> chooseDirection());
        Button swap = makeButton("⇄", BLUE, WHITE, 15);
        directionCard.addView(swap, new LinearLayout.LayoutParams(dp(50), dp(43)));
        swap.setOnClickListener(v -> {
            direction = direction % 2 == 0 ? direction + 1 : direction - 1;
            updateDirection();
        });
        screen.addView(directionCard, blockLayout(0));
        updateDirection();

        TextView langs = makeText(t("CHOISIR UNE LANGUE"), 11, MUTED, true);
        langs.setPadding(dp(3), dp(18), 0, dp(9));
        screen.addView(langs);
        LinearLayout firstRow = horizontal();
        LinearLayout secondRow = horizontal();
        for (int i = 0; i < LANG_NAMES.length; i++) {
            final int selected = i;
            LinearLayout row = i < 3 ? firstRow : secondRow;
            TextView tile = makeText(LANG_FLAGS[i] + " " + LANG_NAMES[i] + "\n" + LANG_PLACES[i], 11, TEXT, true);
            tile.setGravity(Gravity.CENTER);
            tile.setMinHeight(dp(66));
            tile.setBackground(rounded(WHITE, 14));
            LinearLayout.LayoutParams tileLayout = new LinearLayout.LayoutParams(0, dp(71), 1f);
            tileLayout.setMargins(dp(3), 0, dp(3), dp(7));
            row.addView(tile, tileLayout);
            tile.setOnClickListener(v -> selectLanguage(selected));
        }
        screen.addView(firstRow);
        screen.addView(secondRow);

        TextView actionsTitle = makeText(t("OUTILS"), 11, MUTED, true);
        actionsTitle.setPadding(dp(3), dp(11), 0, dp(9));
        screen.addView(actionsTitle);
        LinearLayout actions = horizontal();
        addAction(actions, "✍", t("Écrire"), () -> {
            sourceInput.requestFocus();
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .showSoftInput(sourceInput, InputMethodManager.SHOW_IMPLICIT);
        });
        addAction(actions, "📷", t("Photo"), this::takePhoto);
        addAction(actions, "▧", t("Image"), this::openImage);
        addAction(actions, "◉", t("Écouter"), this::startVoiceRecognition);
        screen.addView(actions);

        LinearLayout inputCard = card();
        LinearLayout inputHeading = horizontal();
        inputHeading.setGravity(Gravity.CENTER_VERTICAL);
        inputHeading.addView(makeText(t("TEXTE ORIGINAL"), 12, MUTED, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button clear = makeButton(t("Effacer"), BLUE_LIGHT, BLUE, 12);
        inputHeading.addView(clear);
        clear.setOnClickListener(v -> {
            sourceInput.setText("");
            hasTranslatedResult = false;
            resultValue.setText(t("Votre traduction apparaîtra ici."));
            setStatus("Prêt à traduire.");
        });
        inputCard.addView(inputHeading);
        sourceInput = new EditText(this);
        sourceInput.setTextSize(16);
        sourceInput.setTextColor(TEXT);
        sourceInput.setHintTextColor(MUTED);
        sourceInput.setHint(t("Écrivez votre texte ou utilisez le microphone…"));
        sourceInput.setHintTextColor(Color.rgb(139, 155, 174));
        sourceInput.setGravity(Gravity.TOP | Gravity.START);
        sourceInput.setMinLines(3);
        sourceInput.setMaxLines(8);
        sourceInput.setSingleLine(false);
        sourceInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        sourceInput.setBackgroundColor(Color.TRANSPARENT);
        inputCard.addView(sourceInput, blockLayout(5));
        LinearLayout.LayoutParams inputParams = blockLayout(0);
        inputParams.topMargin = dp(15);
        screen.addView(inputCard, inputParams);

        LinearLayout micRow = horizontal();
        micRow.setGravity(Gravity.CENTER);
        Button mic = makeButton("🎙", BLUE, WHITE, 28);
        mic.setBackground(gradient(Color.rgb(28, 113, 255), Color.rgb(25, 183, 215), 48));
        mic.setContentDescription("Dicter une phrase au microphone");
        micRow.addView(mic, new LinearLayout.LayoutParams(dp(78), dp(78)));
        mic.setOnClickListener(v -> startVoiceRecognition());
        LinearLayout.LayoutParams micParams = blockLayout(0);
        micParams.topMargin = dp(15);
        screen.addView(micRow, micParams);
        TextView micTip = makeText(t("Touchez pour parler"), 12, MUTED, false);
        micTip.setGravity(Gravity.CENTER);
        micTip.setPadding(0, dp(6), 0, dp(11));
        screen.addView(micTip);

        translateButton = makeButton(t("TRADUIRE MAINTENANT    →"), BLUE, WHITE, 16);
        translateButton.setAllCaps(false);
        screen.addView(translateButton, new LinearLayout.LayoutParams(-1, dp(53)));
        translateButton.setOnClickListener(v -> translate());

        LinearLayout resultCard = card();
        LinearLayout resultHeading = horizontal();
        resultHeading.setGravity(Gravity.CENTER_VERTICAL);
        resultHeading.addView(makeText(t("TRADUCTION"), 12, BLUE, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView done = makeText(t("●  Résultat"), 11, Color.rgb(25, 151, 121), true);
        resultHeading.addView(done);
        resultCard.addView(resultHeading);
        resultValue = makeText(t("Votre traduction apparaîtra ici."), 18, NAVY, false);
        resultValue.setTextIsSelectable(true);
        resultValue.setMinHeight(dp(83));
        resultValue.setPadding(0, dp(13), 0, dp(9));
        resultCard.addView(resultValue);
        LinearLayout resultActions = horizontal();
        addResultAction(resultActions, t("Copier"), this::copyResult);
        addResultAction(resultActions, t("🔊 Lire"), this::speakResult);
        addResultAction(resultActions, t("Partager"), this::shareResult);
        addResultAction(resultActions, t("☆ Favori"), this::addFavorite);
        resultCard.addView(resultActions);
        LinearLayout.LayoutParams resultParams = blockLayout(0);
        resultParams.topMargin = dp(15);
        screen.addView(resultCard, resultParams);

        LinearLayout footer = horizontal();
        footer.setGravity(Gravity.CENTER_VERTICAL);
        addFooterButton(footer, t("Historique"), this::showHistory);
        addFooterButton(footer, t("Favoris"), this::showFavorites);
        addFooterButton(footer, t("⚙ Réglages"), this::showSettings);
        LinearLayout.LayoutParams footerParams = blockLayout(0);
        footerParams.topMargin = dp(16);
        screen.addView(footer, footerParams);

        statusValue = makeText(t("Prêt • Première traduction : téléchargement des modèles nécessaires."),
                12, MUTED, false);
        statusValue.setGravity(Gravity.CENTER);
        statusValue.setPadding(dp(7), dp(15), dp(7), 0);
        screen.addView(statusValue);
        TextView credit = makeText(t("Développé par Moussa Khalid  •  DuaLang 15 Pro"), 11, MUTED, false);
        credit.setGravity(Gravity.CENTER);
        credit.setPadding(0, dp(13), 0, 0);
        screen.addView(credit);
    }

    private void selectLanguage(int index) {
        if (index == 0) {
            chooseDirection();
            return;
        }
        direction = 2 * index - 2;
        updateDirection();
    }

    private void chooseDirection() {
        String[] titles = new String[DIRECTIONS.length];
        for (int i = 0; i < DIRECTIONS.length; i++) {
            int a = DIRECTIONS[i][0];
            int b = DIRECTIONS[i][1];
            titles[i] = LANG_FLAGS[a] + " " + LANG_NAMES[a] + "  →  " + LANG_FLAGS[b] + " " + LANG_NAMES[b];
        }
        new AlertDialog.Builder(this)
                .setTitle(t("Choisir un des 8 sens de traduction"))
                .setSingleChoiceItems(titles, direction, (dialog, selected) -> {
                    direction = selected;
                    updateDirection();
                    dialog.dismiss();
                })
                .setNegativeButton("Annuler", null).show();
    }

    private void updateDirection() {
        int src = DIRECTIONS[direction][0];
        int dst = DIRECTIONS[direction][1];
        directionLabel.setText(LANG_FLAGS[src] + " " + LANG_NAMES[src]
                + "\n     →     " + LANG_FLAGS[dst] + " " + LANG_NAMES[dst]);
        getPreferences(MODE_PRIVATE).edit().putInt("direction", direction).apply();
        hasTranslatedResult = false;
        if (resultValue != null) resultValue.setText(t("Votre traduction apparaîtra ici."));
        setStatus("Direction : " + LANG_NAMES[src] + " → " + LANG_NAMES[dst]);
    }

    private void translate() {
        String text = sourceInput.getText().toString().trim();
        if (text.isEmpty()) {
            sourceInput.setError("Écrivez ou dictez d'abord un texte.");
            sourceInput.requestFocus();
            return;
        }
        int src = DIRECTIONS[direction][0];
        int dst = DIRECTIONS[direction][1];
        final int request = ++translationRequest;
        translateButton.setEnabled(false);
        setStatus("Vérification du modèle de traduction…");
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(LANG_CODES[src])
                .setTargetLanguage(LANG_CODES[dst])
                .build();
        Translator translator = Translation.getClient(options);
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        // The first run requires connectivity. Subsequent runs use cached on-device models.
        boolean offlineOnly = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("offline_only", false);
        if (offlineOnly) {
            translateWithInstalledModels(translator, text, request, src, dst);
            return;
        }
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(unused -> {
                    if (destroyed || request != translationRequest) {
                        translator.close();
                        return;
                    }
                    setStatus("Traduction locale en cours…");
                    translator.translate(text)
                            .addOnSuccessListener(result -> {
                                if (!destroyed && request == translationRequest) {
                                    hasTranslatedResult = true;
                                    resultValue.setText(result);
                                    saveHistory(text, result, false, src, dst);
                                    setStatus("Traduction terminée • Modèle utilisable hors ligne.");
                                }
                            })
                            .addOnFailureListener(error -> {
                                if (!destroyed && request == translationRequest)
                                    setStatus("Échec de traduction : " + error.getMessage());
                            })
                            .addOnCompleteListener(task -> {
                                translator.close();
                                if (!destroyed && request == translationRequest)
                                    translateButton.setEnabled(true);
                            });
                })
                .addOnFailureListener(error -> {
                    translator.close();
                    if (!destroyed && request == translationRequest) {
                        setStatus("Modèle non disponible. Activez Internet puis réessayez. "
                                + friendlyError(error));
                        translateButton.setEnabled(true);
                    }
                });
    }

    private void translateWithInstalledModels(Translator translator, String text, int request,
                                            int src, int dst) {
        RemoteModelManager manager = RemoteModelManager.getInstance();
        TranslateRemoteModel sourceModel = new TranslateRemoteModel.Builder(LANG_CODES[src]).build();
        TranslateRemoteModel destinationModel = new TranslateRemoteModel.Builder(LANG_CODES[dst]).build();
        manager.isModelDownloaded(sourceModel).addOnSuccessListener(sourceReady ->
                manager.isModelDownloaded(destinationModel).addOnSuccessListener(destinationReady -> {
                    if (destroyed || request != translationRequest) {
                        translator.close();
                        return;
                    }
                    if (!sourceReady || !destinationReady) {
                        translator.close();
                        translateButton.setEnabled(true);
                        setStatus(t("Modèles absents : ouvrez les réglages et téléchargez-les avec Internet."));
                        return;
                    }
                    translator.translate(text).addOnSuccessListener(result -> {
                        if (!destroyed && request == translationRequest) {
                            hasTranslatedResult = true;
                            resultValue.setText(result);
                            saveHistory(text, result, false, src, dst);
                            setStatus(t("Traduction terminée • Mode hors ligne."));
                        }
                    }).addOnFailureListener(error -> {
                        if (!destroyed && request == translationRequest) setStatus("Traduction : " + friendlyError(error));
                    }).addOnCompleteListener(task -> {
                        translator.close();
                        if (!destroyed && request == translationRequest) translateButton.setEnabled(true);
                    });
                }).addOnFailureListener(error -> offlineFailure(translator, request, error))
        ).addOnFailureListener(error -> offlineFailure(translator, request, error));
    }

    private void offlineFailure(Translator translator, int request, Exception error) {
        translator.close();
        if (!destroyed && request == translationRequest) {
            translateButton.setEnabled(true);
            setStatus("Mode hors ligne : " + friendlyError(error));
        }
    }

    private void startVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, SPEECH_CODES[DIRECTIONS[direction][0]]);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez en " + LANG_NAMES[DIRECTIONS[direction][0]]);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            startActivityForResult(intent, REQUEST_SPEECH);
        } catch (ActivityNotFoundException error) {
            setStatus("Reconnaissance vocale non disponible : installez un service vocal Android.");
        }
    }

    private void openImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try {
            startActivityForResult(intent, REQUEST_IMAGE);
        } catch (ActivityNotFoundException error) {
            setStatus("Impossible d'ouvrir le sélecteur d'images.");
        }
    }

    private void takePhoto() {
        Intent capture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            File folder = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (folder == null) folder = getCacheDir();
            File output = File.createTempFile("dualang_photo_", ".jpg", folder);
            pendingCameraUri = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", output);
            capture.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            capture.setClipData(ClipData.newUri(getContentResolver(), "photo", pendingCameraUri));
            capture.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(capture, REQUEST_CAMERA);
        } catch (IOException | ActivityNotFoundException | IllegalArgumentException error) {
            setStatus("Caméra indisponible : " + friendlyError(error));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        if (requestCode == REQUEST_CAMERA && pendingCameraUri != null) {
            extractText(pendingCameraUri);
        } else if (requestCode == REQUEST_IMAGE && data != null && data.getData() != null) {
            extractText(data.getData());
        } else if (requestCode == REQUEST_SPEECH && data != null) {
            ArrayList<String> phrases = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (phrases != null && !phrases.isEmpty()) {
                sourceInput.setText(phrases.get(0));
                setStatus("Dictée reçue. Vous pouvez traduire.");
                translate();
            }
        }
    }

    private void extractText(Uri uri) {
        setStatus("Reconnaissance du texte dans l'image…");
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        if (destroyed) return;
                        String found = result.getText().trim();
                        if (found.isEmpty()) {
                            setStatus("Aucun texte détecté. Essayez une photo plus nette.");
                        } else {
                            sourceInput.setText(found);
                            setStatus("Texte détecté : " + found.length() + " caractères.");
                            translate();
                        }
                    })
                    .addOnFailureListener(error -> {
                        if (!destroyed) setStatus("OCR : " + friendlyError(error));
                    })
                    .addOnCompleteListener(task -> recognizer.close());
        } catch (IOException error) {
            setStatus("Impossible de lire cette image : " + friendlyError(error));
        }
    }

    private void copyResult() {
        String value = resultValue.getText().toString();
        if (!hasResult()) return;
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager)
                getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Traduction DuaLang", value));
        Toast.makeText(this, "Traduction copiée", Toast.LENGTH_SHORT).show();
    }

    private void speakResult() {
        if (!hasResult()) return;
        if (textToSpeech == null) {
            setStatus("Synthèse vocale indisponible.");
            return;
        }
        String code = SPEECH_CODES[DIRECTIONS[direction][1]];
        int availability = textToSpeech.setLanguage(Locale.forLanguageTag(code));
        if (availability == TextToSpeech.LANG_MISSING_DATA
                || availability == TextToSpeech.LANG_NOT_SUPPORTED) {
            setStatus("Voix " + LANG_NAMES[DIRECTIONS[direction][1]]
                    + " absente. Installez la langue dans les paramètres TTS Android.");
            return;
        }
        textToSpeech.speak(resultValue.getText().toString(),
                TextToSpeech.QUEUE_FLUSH, null, "dualang_150");
    }

    private void shareResult() {
        if (!hasResult()) return;
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, resultValue.getText().toString());
        startActivity(Intent.createChooser(intent, "Partager avec WhatsApp ou une autre application"));
    }

    private boolean hasResult() {
        String value = resultValue.getText().toString();
        if (!hasTranslatedResult || value.trim().isEmpty()) {
            Toast.makeText(this, "Traduisez un texte d'abord", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void addFavorite() {
        if (!hasResult()) return;
        saveHistory(sourceInput.getText().toString(), resultValue.getText().toString(), true,
                DIRECTIONS[direction][0], DIRECTIONS[direction][1]);
        setStatus("Traduction ajoutée aux favoris ★");
    }

    private void saveHistory(String source, String result, boolean favorite, int src, int dst) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        JSONArray oldEntries;
        try {
            oldEntries = new JSONArray(prefs.getString(KEY_HISTORY, "[]"));
        } catch (Exception ignored) {
            oldEntries = new JSONArray();
        }
        JSONArray entries = new JSONArray();
        try {
            JSONObject item = new JSONObject();
            item.put("source", source);
            item.put("result", result);
            item.put("src", src);
            item.put("dst", dst);
            item.put("star", favorite);
            item.put("at", System.currentTimeMillis());
            entries.put(item);
            for (int i = 0; i < oldEntries.length() && entries.length() < 50; i++) {
                JSONObject old = oldEntries.optJSONObject(i);
                if (old != null) entries.put(old);
            }
        } catch (Exception ignored) {
            return;
        }
        prefs.edit().putString(KEY_HISTORY, entries.toString()).apply();
    }

    private void showHistory() {
        showSaved(false);
    }

    private void showFavorites() {
        showSaved(true);
    }

    private void showSaved(boolean favoritesOnly) {
        JSONArray entries;
        try {
            entries = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_HISTORY, "[]"));
        } catch (Exception ignored) {
            entries = new JSONArray();
        }
        List<JSONObject> selected = new ArrayList<>();
        List<String> titles = new ArrayList<>();
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry == null || (favoritesOnly && !entry.optBoolean("star"))) continue;
            int a = entry.optInt("src", 0);
            int b = entry.optInt("dst", 1);
            if (a < 0 || a >= LANG_NAMES.length || b < 0 || b >= LANG_NAMES.length) continue;
            selected.add(entry);
            String heading = (entry.optBoolean("star") ? "★ " : "")
                    + LANG_FLAGS[a] + " → " + LANG_FLAGS[b] + "  "
                    + new SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
                    .format(new Date(entry.optLong("at", System.currentTimeMillis())));
            titles.add(heading + "\n" + shorten(entry.optString("source"), 80)
                    + "\n→ " + shorten(entry.optString("result"), 80));
        }
        if (titles.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle(favoritesOnly ? t("Favoris") : t("Historique"))
                    .setMessage("Aucune traduction enregistrée pour le moment.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(favoritesOnly ? "Mes favoris" : "Mes 50 dernières traductions")
                .setItems(titles.toArray(new String[0]), (dialog, which) -> {
                    if (which < 0 || which >= selected.size()) return;
                    JSONObject entry = selected.get(which);
                    sourceInput.setText(entry.optString("source"));
                    hasTranslatedResult = true;
                    resultValue.setText(entry.optString("result"));
                    int src = entry.optInt("src", 0);
                    int dst = entry.optInt("dst", 1);
                    for (int j = 0; j < DIRECTIONS.length; j++) {
                        if (DIRECTIONS[j][0] == src && DIRECTIONS[j][1] == dst) {
                            direction = j;
                            updateDirection();
                            hasTranslatedResult = true;
                            resultValue.setText(entry.optString("result"));
                            break;
                        }
                    }
                    setStatus("Traduction restaurée depuis l'historique.");
                })
                .setNegativeButton("Fermer", null).show();
    }

    private void showSettings() {
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void setStatus(String message) {
        if (statusValue != null) statusValue.setText(message);
    }

    private String friendlyError(Exception error) {
        return error.getLocalizedMessage() == null ? error.getClass().getSimpleName()
                : error.getLocalizedMessage();
    }

    private String shorten(String text, int max) {
        return text.length() <= max ? text : text.substring(0, max - 1) + "…";
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        translationRequest++;
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    private void addAction(LinearLayout container, String glyph, String label, Runnable callback) {
        LinearLayout tile = vertical();
        tile.setPadding(dp(2), dp(10), dp(2), dp(11));
        tile.setGravity(Gravity.CENTER);
        tile.setBackground(rounded(WHITE, 16));
        TextView icon = makeText(glyph, 24, BLUE, true);
        icon.setGravity(Gravity.CENTER);
        tile.addView(icon);
        TextView text = makeText(label, 12, TEXT, true);
        text.setGravity(Gravity.CENTER);
        text.setPadding(0, dp(7), 0, 0);
        tile.addView(text);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(77), 1f);
        params.setMargins(dp(3), 0, dp(3), 0);
        container.addView(tile, params);
        tile.setOnClickListener(v -> callback.run());
    }

    private void addResultAction(LinearLayout container, String label, Runnable callback) {
        Button button = makeButton(label, BLUE_LIGHT, BLUE, 11);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(42), 1f);
        params.setMargins(dp(2), 0, dp(2), 0);
        container.addView(button, params);
        button.setOnClickListener(v -> callback.run());
    }

    private void addFooterButton(LinearLayout container, String label, Runnable callback) {
        Button button = makeButton(label, WHITE, NAVY, 12);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(49), 1f);
        params.setMargins(dp(3), 0, dp(3), 0);
        container.addView(button, params);
        button.setOnClickListener(v -> callback.run());
    }

    private LinearLayout card() {
        LinearLayout card = vertical();
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(rounded(WHITE, 19));
        return card;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        return layout;
    }

    private TextView makeText(String text, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button makeButton(String text, int background, int foreground, int sp) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(foreground);
        button.setTextSize(sp);
        button.setAllCaps(false);
        button.setBackground(rounded(background, 14));
        button.setPadding(dp(4), 0, dp(4), 0);
        return button;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private GradientDrawable gradient(int first, int second, int radius) {
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{first, second});
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private LinearLayout.LayoutParams blockLayout(int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(bottom);
        return params;
    }

    private int dp(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
