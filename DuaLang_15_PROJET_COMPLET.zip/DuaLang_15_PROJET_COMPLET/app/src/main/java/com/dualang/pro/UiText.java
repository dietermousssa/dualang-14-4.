package com.dualang.pro;

import android.content.Context;
import java.util.HashMap;
import java.util.Map;

/** Core-screen UI locale: French, English, Indonesian, Vietnamese and Filipino. */
public final class UiText {
    private static final Map<String, String[]> TEXT = new HashMap<>();
    private UiText() { }
    private static void add(String fr, String en, String id, String vi, String fil) {
        TEXT.put(fr, new String[]{fr, en, id, vi, fil});
    }
    static {
        add("INTERFACE PRO  •  TRADUCTION INTELLIGENTE", "PRO INTERFACE  •  SMART TRANSLATION", "ANTARMUKA PRO • TERJEMAH CERDAS", "GIAO DIỆN PRO • DỊCH THÔNG MINH", "PRO INTERFACE • MATALINONG PAGSASALIN");
        add("Parlez, écrivez ou photographiez. Traduisez dans 5 langues, même hors ligne après téléchargement des modèles.", "Speak, type or take a photo. Translate in 5 languages, even offline after downloading models.", "Bicara, ketik, atau foto. Terjemahkan 5 bahasa, juga offline setelah mengunduh model.", "Nói, nhập hoặc chụp ảnh. Dịch 5 ngôn ngữ, kể cả ngoại tuyến sau khi tải mô hình.", "Magsalita, mag-type o kumuha ng larawan. Isalin sa 5 wika, kahit offline kapag na-download ang mga modelo.");
        add("DIRECTION DE TRADUCTION", "TRANSLATION DIRECTION", "ARAH TERJEMAHAN", "HƯỚNG DỊCH", "DIREKSYON NG SALIN");
        add("CHOISIR UNE LANGUE", "CHOOSE A LANGUAGE", "PILIH BAHASA", "CHỌN NGÔN NGỮ", "PUMILI NG WIKA");
        add("OUTILS", "TOOLS", "ALAT", "CÔNG CỤ", "MGA TOOL");
        add("Écrire", "Type", "Tulis", "Nhập", "Sulatin");
        add("Photo", "Camera", "Kamera", "Ảnh chụp", "Kamera");
        add("Image", "Image", "Gambar", "Hình ảnh", "Larawan");
        add("Écouter", "Listen", "Dengar", "Nghe", "Makinig");
        add("TEXTE ORIGINAL", "SOURCE TEXT", "TEKS ASLI", "VĂN BẢN GỐC", "ORIHINAL NA TEKSTO");
        add("Effacer", "Clear", "Hapus", "Xóa", "Burahin");
        add("Écrivez votre texte ou utilisez le microphone…", "Enter text or use the microphone…", "Masukkan teks atau gunakan mikrofon…", "Nhập văn bản hoặc dùng micrô…", "Maglagay ng teksto o gamitin ang mikropono…");
        add("Touchez pour parler", "Tap to speak", "Ketuk untuk bicara", "Chạm để nói", "Pindutin para magsalita");
        add("TRADUIRE MAINTENANT    →", "TRANSLATE NOW    →", "TERJEMAHKAN SEKARANG    →", "DỊCH NGAY    →", "ISALIN NGAYON    →");
        add("TRADUCTION", "TRANSLATION", "TERJEMAHAN", "BẢN DỊCH", "SALIN");
        add("●  Résultat", "●  Result", "●  Hasil", "●  Kết quả", "●  Resulta");
        add("Votre traduction apparaîtra ici.", "Your translation will appear here.", "Hasil terjemahan tampil di sini.", "Bản dịch của bạn sẽ xuất hiện ở đây.", "Lalabas dito ang iyong salin.");
        add("Copier", "Copy", "Salin", "Sao chép", "Kopyahin");
        add("🔊 Lire", "🔊 Speak", "🔊 Baca", "🔊 Đọc", "🔊 Basahin");
        add("Partager", "Share", "Bagikan", "Chia sẻ", "Ibahagi");
        add("☆ Favori", "☆ Favorite", "☆ Favorit", "☆ Yêu thích", "☆ Paborito");
        add("Historique", "History", "Riwayat", "Lịch sử", "Kasaysayan");
        add("Favoris", "Favorites", "Favorit", "Yêu thích", "Mga paborito");
        add("⚙ Réglages", "⚙ Settings", "⚙ Pengaturan", "⚙ Cài đặt", "⚙ Mga setting");
        add("Prêt • Première traduction : téléchargement des modèles nécessaires.", "Ready • Translation models download on first use.", "Siap • Model terjemahan diunduh saat pertama kali.", "Sẵn sàng • Tải mô hình khi sử dụng lần đầu.", "Handa • Ida-download ang mga modelo sa unang gamit.");
        add("Développé par Moussa Khalid  •  DuaLang 15 Pro", "Developed by Moussa Khalid  •  DuaLang 15 Pro", "Dikembangkan oleh Moussa Khalid • DuaLang 15 Pro", "Phát triển bởi Moussa Khalid • DuaLang 15 Pro", "Ginawa ni Moussa Khalid • DuaLang 15 Pro");
        add("Choisir un des 8 sens de traduction", "Choose one of 8 translation directions", "Pilih 1 dari 8 arah terjemahan", "Chọn 1 trong 8 hướng dịch", "Pumili sa 8 direksyon ng salin");
        add("Mode hors ligne actif : seuls les modèles déjà installés seront utilisés.", "Offline only: only installed models will be used.", "Mode offline: hanya model yang terpasang digunakan.", "Ngoại tuyến: chỉ dùng các mô hình đã cài.", "Offline: mga naka-install na modelo lang ang gagamitin.");
        add("Mode automatique : téléchargement initial possible via Internet.", "Automatic mode: initial downloads may use Internet.", "Mode otomatis: unduhan awal membutuhkan internet.", "Tự động: có thể tải qua mạng khi dùng lần đầu.", "Awtomatiko: maaaring gumamit ng internet sa unang download.");
        add("Modèles absents : ouvrez les réglages et téléchargez-les avec Internet.", "Models missing: open Settings and download them online.", "Model belum ada: buka Pengaturan dan unduh melalui internet.", "Thiếu mô hình: mở Cài đặt để tải khi có mạng.", "Kulang ang modelo: buksan ang Mga setting at i-download online.");
        add("Traduction terminée • Mode hors ligne.", "Translation complete • Offline.", "Terjemahan selesai • Offline.", "Dịch xong • Ngoại tuyến.", "Tapos ang pagsasalin • Offline.");
        add("Réglages", "Settings", "Pengaturan", "Cài đặt", "Mga setting");
        add("Langue de l’interface", "Interface language", "Bahasa antarmuka", "Ngôn ngữ giao diện", "Wika ng interface");
        add("Mode hors ligne uniquement", "Offline mode only", "Mode offline saja", "Chỉ dùng ngoại tuyến", "Offline mode lamang");
        add("Utiliser uniquement les modèles de traduction déjà téléchargés.", "Use already-downloaded translation models only.", "Hanya gunakan model terjemahan yang sudah diunduh.", "Chỉ dùng các mô hình đã tải xuống.", "Gamitin lamang ang mga modelong na-download na.");
        add("Télécharger les modèles", "Download models", "Unduh model", "Tải mô hình", "I-download ang mga modelo");
        add("Télécharger les 5 langues pour traduire hors ligne.", "Download all 5 languages for offline translation.", "Unduh 5 bahasa untuk terjemahan offline.", "Tải 5 ngôn ngữ để dịch ngoại tuyến.", "I-download ang 5 wika para sa offline na salin.");
        add("Effacer l’historique", "Clear history", "Hapus riwayat", "Xóa lịch sử", "Burahin ang kasaysayan");
        add("Supprimer les traductions et favoris enregistrés.", "Delete saved translations and favorites.", "Hapus terjemahan dan favorit tersimpan.", "Xóa bản dịch và mục yêu thích đã lưu.", "Burahin ang mga naka-save na salin at paborito.");
        add("À propos et confidentialité", "About & privacy", "Tentang & privasi", "Giới thiệu & riêng tư", "Tungkol dito at privacy");
        add("Retour", "Back", "Kembali", "Quay lại", "Bumalik");
        add("Annuler", "Cancel", "Batal", "Hủy", "Kanselahin");
        add("Confirmer", "Confirm", "Konfirmasi", "Xác nhận", "Kumpirmahin");
    }
    public static String get(Context context, String french) {
        String code = context.getSharedPreferences("dualang_14_4", Context.MODE_PRIVATE)
                .getString("ui_language", "fr");
        int idx;
        switch (code) {
            case "en": idx = 1; break;
            case "id": idx = 2; break;
            case "vi": idx = 3; break;
            case "tl": idx = 4; break;
            default: idx = 0;
        }
        String[] values = TEXT.get(french);
        return values == null ? french : values[idx];
    }
}
