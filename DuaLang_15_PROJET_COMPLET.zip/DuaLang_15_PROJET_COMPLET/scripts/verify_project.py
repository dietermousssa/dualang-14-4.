#!/usr/bin/env python3
"""Static verification only. GitHub Actions compiles the actual APK."""
import re
from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
required = [
    "settings.gradle", "build.gradle", "gradle.properties", "app/build.gradle",
    "app/src/main/AndroidManifest.xml", "app/src/main/res/xml/file_paths.xml",
    "app/src/main/res/values/strings.xml", "app/src/main/res/values/styles.xml",
    "app/src/main/java/com/dualang/pro/MainActivity.java",
    "app/src/main/java/com/dualang/pro/SettingsActivity.java",
    "app/src/main/java/com/dualang/pro/UiText.java",
    ".github/workflows/android-apk.yml",
]
for path in required:
    assert (root/path).is_file(), "Missing: " + path
for xml in root.rglob("*.xml"):
    ET.parse(xml)
app=(root/"app/build.gradle").read_text()
assert re.search(r"versionCode\s+150\b", app), "Version code not 150"
assert "versionName '15.0'" in app, "Version not 15.0"
assert "com.dualang.pro" in app, "Application ID changed: update history compatibility"
assert "com.google.mlkit:translate:17.0.3" in app
assert "com.google.mlkit:text-recognition:16.0.1" in app
manifest=(root/"app/src/main/AndroidManifest.xml").read_text()
assert ".SettingsActivity" in manifest
main=(root/"app/src/main/java/com/dualang/pro/MainActivity.java").read_text()
settings=(root/"app/src/main/java/com/dualang/pro/SettingsActivity.java").read_text()
ui=(root/"app/src/main/java/com/dualang/pro/UiText.java").read_text()
for feature in ["TextRecognition.getClient", "Translation.getClient", "ACTION_RECOGNIZE_SPEECH", "TextToSpeech", "showHistory", "showFavorites", "FileProvider.getUriForFile", "translateWithInstalledModels", "SettingsActivity.class", "dualang_14_4", "Développé par Moussa Khalid"]:
    assert feature in main, "Feature missing: " + feature
for feature in ["offline_only", "ui_language", "RemoteModelManager", "downloadModels", "getString", "dualang_14_4"]:
    assert feature in settings, "Settings feature missing: " + feature
block=re.search(r"private static final int\[\]\[\] DIRECTIONS\s*=\s*\{(.*?)\};",main,re.S)
assert block is not None
assert len(re.findall(r"\{\s*\d+\s*,\s*\d+\s*\}",block.group(1)))==8
for lang in ['fr','en','id','vi','tl']:
    assert '\"'+lang+'\"' in ui, 'UI language missing '+lang
assert 'upload-artifact@v4' in (root/'.github/workflows/android-apk.yml').read_text()
# Coarse syntactic braces check (Java strings/comments accounted for)
def check_braces(code):
    code=re.sub(r'"(?:\\.|[^"\\])*"', '""', code)
    code=re.sub(r'//[^\n]*|/\*.*?\*/', '', code, flags=re.S)
    counts={op: code.count(op) for op in '({['}
    for op,close in [('(',')'),('{','}'),('[',']')]:
        assert code.count(op)==code.count(close), f"Unbalanced Java {op}/{close}"
for f in (root/'app/src/main/java').rglob('*.java'):
    check_braces(f.read_text())
print('OK - 3 Java classes, XML, 5 languages, 8 directions, version 15.0, ML Kit libraries, offline/settings, GitHub workflow')
